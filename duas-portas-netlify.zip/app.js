'use strict';

// Presentation order includes two analysis reveals and one post-credit reveal.
const DeckState = (() => {
  const beats = [0, 0, 1, 0, 1, 1];
  function normalize(scene, beat = 0) {
    const safeScene = Number.isInteger(scene) ? Math.max(0, Math.min(5, scene)) : 0;
    return {scene:safeScene, beat:Math.max(0, Math.min(beats[safeScene], Number.isInteger(beat) ? beat : 0))};
  }
  function forward(state) {
    if (state.beat < beats[state.scene]) return normalize(state.scene, state.beat + 1);
    return normalize(state.scene === 5 ? 0 : state.scene + 1);
  }
  function backward(state) {
    if (state.beat > 0) return normalize(state.scene, state.beat - 1);
    return state.scene > 0 ? normalize(state.scene - 1, beats[state.scene - 1]) : normalize(0);
  }
  function parse(hash) {
    const match = hash.match(/^#cena-([1-6])(?:-([12]))?$/);
    return match ? normalize(Number(match[1]) - 1, Number(match[2] || 1) - 1) : normalize(0);
  }
  function hash(state) { return `#cena-${state.scene + 1}${state.beat ? '-2' : ''}`; }
  return Object.freeze({beats, normalize, forward, backward, parse, hash});
})();

// Surface, motion and controls.
const slides = Array.from(document.querySelectorAll('.slide'));
const sceneNames = ['Abertura', 'Primeiro conto', 'Desejo e pertencimento', 'Segundo conto', 'Voz e resistência', 'Nossa leitura'];
const sceneTitles = ['Duas portas, duas histórias', 'Na segunda-feira da semana passada', 'A vontade de ser vista', 'Jumping Monkey Hill', 'O poder de calar uma voz', 'Nenhuma vida cabe num rótulo'];
const sceneImages = ['doors', 'home', 'home', 'workshop', 'workshop', 'doors'];
const surface = document.getElementById('presentation');
const nextButton = document.getElementById('next');
const previousButton = document.getElementById('previous');
const portalLayer = document.getElementById('portal-transition');
const notesDialog = document.getElementById('notes-dialog');
const sourcesDialog = document.getElementById('sources-dialog');
const overviewDialog = document.getElementById('overview-dialog');
const dialogs = [notesDialog, sourcesDialog, overviewDialog];
const menu = document.querySelector('.options-menu');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const easing = 'cubic-bezier(.22,.7,.18,1)';
const runningAnimations = new Set();
let state = DeckState.normalize(0);
let moving = false;
let noticeTimer;

function animate(element, frames, options = {}) {
  if (!element || typeof element.animate !== 'function' || reduceMotion.matches) return Promise.resolve();
  const animation = element.animate(frames, {duration:800, easing, fill:'both', ...options});
  runningAnimations.add(animation);
  return animation.finished.catch(() => {});
}

function clearAnimations() {
  for (const animation of runningAnimations) animation.cancel();
  runningAnimations.clear();
}

function applyReveal(slide, beat) {
  slide.classList.toggle('is-revealed', beat > 0);
  slide.querySelectorAll('[data-reveal-content]').forEach(element => {
    element.hidden = beat === 0;
    element.inert = beat === 0;
    element.setAttribute('aria-hidden', beat === 0 ? 'true' : 'false');
  });
  slide.querySelectorAll('.reveal-teaser').forEach(element => {
    element.hidden = beat > 0;
    element.inert = beat > 0;
  });
  const seriousEnding = slide.querySelector('[data-ending-serious]');
  if (seriousEnding) {
    seriousEnding.inert = beat > 0;
    seriousEnding.setAttribute('aria-hidden', beat > 0 ? 'true' : 'false');
  }
}

function updateControls(updateHash = true) {
  document.getElementById('current-number').textContent = String(state.scene + 1).padStart(2, '0');
  document.getElementById('scene-name').textContent = sceneNames[state.scene];
  let label = ['Entrar no primeiro conto', 'Aproximar o olhar', 'Entrar no segundo conto', 'Virar a página', 'Unir as histórias', 'Voltar ao início'][state.scene];
  if (state.beat < DeckState.beats[state.scene]) {
    if (state.scene === 2) label = 'Revelar o desfecho';
    else if (state.scene === 4) label = 'Revelar a resposta';
    else label = 'Encerrar apresentação';
  }
  document.getElementById('next-label').textContent = label;
  nextButton.setAttribute('aria-label', label);
  previousButton.disabled = state.scene === 0 && state.beat === 0;
  document.getElementById('progress').style.width = `${(state.scene + 1) / 6 * 100}%`;
  document.querySelectorAll('.scene-index button').forEach((button, index) => {
    if (index === state.scene) button.setAttribute('aria-current', 'step');
    else button.removeAttribute('aria-current');
  });
  if (updateHash) {
    try { history.replaceState(null, '', DeckState.hash(state)); } catch (_) { /* Hash is optional in embedded presentations. */ }
  }
}

function commit(target, focus = true, updateHash = true) {
  state = DeckState.normalize(target.scene, target.beat);
  slides.forEach((slide, index) => {
    const active = index === state.scene;
    slide.hidden = !active;
    slide.inert = !active;
    slide.classList.remove('is-staged');
    slide.classList.toggle('is-active', active);
    slide.style.zIndex = '';
    if (active) { applyReveal(slide, state.beat); slide.scrollTop = 0; }
  });
  updateControls(updateHash);
  const revealedMessage = state.beat ? (state.scene === 5 ? ' Pós-créditos revelado.' : ' Desfecho revelado.') : '';
  document.getElementById('announcement').textContent = `Cena ${state.scene + 1} de 6. ${sceneTitles[state.scene]}.${revealedMessage}`;
  if (focus) slides[state.scene].querySelector('h1,h2').focus({preventScroll:true});
}

async function reveal(target) {
  moving = true;
  const slide = slides[state.scene];
  const focusWasHidden = Boolean(document.activeElement.closest('.reveal-teaser'));
  const revealingPostCredit = state.scene === 5 && target.beat > state.beat;
  state = target;
  updateControls();
  if (focusWasHidden) nextButton.focus({preventScroll:true});
  try {
    if (revealingPostCredit && !reduceMotion.matches) {
      const seriousEnding = slide.querySelector('[data-ending-serious]');
      const postCredit = slide.querySelector('.post-credit');
      const flash = slide.querySelector('.tv-flash');
      postCredit.hidden = false;
      postCredit.inert = true;
      postCredit.setAttribute('aria-hidden', 'true');
      slide.classList.add('is-postcredit-entering');
      await Promise.all([
        animate(seriousEnding, [
          {opacity:1, transform:'scale(1)', filter:'brightness(1) saturate(1)'},
          {opacity:.92, transform:'scale(.995)', filter:'brightness(1.35) saturate(0)', offset:.58},
          {opacity:0, transform:'scaleX(1) scaleY(.005)', filter:'brightness(5) saturate(0)'}
        ], {duration:680, easing:'cubic-bezier(.7,0,.84,0)'}),
        animate(flash, [
          {opacity:0, transform:'scaleX(.04)'},
          {opacity:1, transform:'scaleX(1)', offset:.7},
          {opacity:0, transform:'scaleX(.08)'}
        ], {duration:780, easing:'ease-in-out'})
      ]);
      applyReveal(slide, state.beat);
      slide.classList.remove('is-postcredit-entering');
      const parts = Array.from(postCredit.querySelectorAll('[data-postcredit-enter]'));
      await Promise.all(parts.map((element, index) => animate(element, [
        {opacity:0, transform:`translateY(${index % 2 ? 32 : -24}px) scale(.97)`, clipPath:'inset(48% 0 48% 0)'},
        {opacity:1, transform:'translateY(0) scale(1)', clipPath:'inset(0 0 0 0)'}
      ], {duration:760, delay:index * 85})));
      document.getElementById('announcement').textContent = 'Pós-créditos: Assim como nossa sanidade mental, nosso trabalho acabou.';
      return;
    }
    applyReveal(slide, state.beat);
    if (state.beat > 0) {
      const revealed = Array.from(slide.querySelectorAll('[data-reveal-content]'));
      await Promise.all(revealed.map((element, index) => animate(element, [
        {opacity:0, transform:'translateY(24px)', clipPath:'inset(0 0 100% 0)'},
        {opacity:1, transform:'translateY(0)', clipPath:'inset(0 0 0% 0)'}
      ], {duration:720, delay:index * 100})));
      if (state.scene === 2) document.getElementById('announcement').textContent = 'Desfecho: Tracy repete a atenção com outra mulher. A expectativa de uma ligação especial se desfaz.';
      else if (state.scene === 4) document.getElementById('announcement').textContent = 'Desfecho: Ujunwa revela que viveu a experiência que Edward julgou inverossímil.';
      else document.getElementById('announcement').textContent = 'Pós-créditos revelado.';
      if (window.innerWidth <= 650 && revealed[0]) revealed[0].scrollIntoView({block:'nearest', behavior:reduceMotion.matches ? 'auto' : 'smooth'});
    } else {
      document.getElementById('announcement').textContent = state.scene === 5 ? 'Pós-créditos oculto. A conclusão voltou à tela.' : 'Desfecho oculto. A cena pode ser apresentada novamente.';
    }
  } finally {
    clearAnimations();
    moving = false;
  }
}

async function travelThroughDoor(oldSlide, incoming, target, source, activate) {
  const kind = target.scene === 1 ? 'home' : 'workshop';
  const doorCard = source?.closest('.portal-card') || document.querySelector(`[data-portal="${kind}"]`);
  const destination = surface.getBoundingClientRect();
  let origin = state.scene === 0 ? doorCard?.querySelector('.portal-visual').getBoundingClientRect() : null;
  if (!origin || origin.width < 1) {
    origin = {left:destination.left + destination.width * .57, top:destination.top + destination.height * .1, width:destination.width * .24, height:destination.height * .8};
  }
  const plane = portalLayer.querySelector('.flight-plane');
  const door = portalLayer.querySelector('.flight-door');
  const room = portalLayer.querySelector('.flight-room');
  const shade = portalLayer.querySelector('.flight-shade');
  const glow = portalLayer.querySelector('.flight-glow');
  portalLayer.hidden = false;
  plane.style.inset = 'auto';
  plane.style.left = `${destination.left}px`;
  plane.style.top = `${destination.top}px`;
  plane.style.width = `${destination.width}px`;
  plane.style.height = `${destination.height}px`;
  room.style.backgroundImage = `url('assets/${kind}.png')`;
  door.style.backgroundPosition = kind === 'home' ? '51% center' : '94% center';
  await Promise.all([
    animate(shade, [{opacity:0}, {opacity:1, offset:.25}, {opacity:1}], {duration:1080}),
    animate(plane, [
      {left:`${origin.left}px`, top:`${origin.top}px`, width:`${origin.width}px`, height:`${origin.height}px`, opacity:1},
      {left:`${destination.left}px`, top:`${destination.top}px`, width:`${destination.width}px`, height:`${destination.height}px`, opacity:1}
    ], {duration:1080}),
    animate(door, [{transform:'perspective(1600px) rotateY(0deg)', opacity:1}, {transform:'perspective(1600px) rotateY(-104deg)', opacity:0}], {duration:960, delay:170}),
    animate(room, [{transform:'scale(1.36)', filter:'brightness(.65)'}, {transform:'scale(1.03)', filter:'brightness(1)'}], {duration:1080}),
    animate(glow, [{opacity:0}, {opacity:.35, offset:.3}, {opacity:0}], {duration:950}),
    animate(oldSlide, [{opacity:1, transform:'scale(1)'}, {opacity:.1, transform:'scale(.97)'}], {duration:480})
  ]);
  activate();
  await animate(portalLayer, [{opacity:1}, {opacity:0}], {duration:280});
}

async function moveCamera(oldSlide, incoming, direction, activate) {
  await Promise.all([
    animate(oldSlide, [{transform:'translateX(0) scale(1)', opacity:1}, {transform:`translateX(${-direction * 18}%) scale(1.23)`, opacity:0}], {duration:950}),
    animate(incoming, [{transform:`translateX(${direction * 16}%) scale(1.12)`, opacity:0}, {transform:'translateX(0) scale(1)', opacity:1}], {duration:950}),
    animate(incoming.querySelector('.desire-environment'), [{transform:'scale(1.18) translateX(2%)'}, {transform:'scale(1) translateX(0)'}], {duration:1100})
  ]);
  activate();
}

async function turnPage(oldSlide, incoming, direction, activate) {
  oldSlide.style.zIndex = '4';
  incoming.style.zIndex = '2';
  oldSlide.style.transformOrigin = direction > 0 ? 'left center' : 'right center';
  await Promise.all([
    animate(oldSlide, [{transform:'perspective(1900px) rotateY(0deg)', opacity:1, filter:'brightness(1)'}, {transform:`perspective(1900px) rotateY(${-direction * 102}deg)`, opacity:0, filter:'brightness(.55)'}], {duration:1050}),
    animate(incoming, [{transform:'scale(.94)', opacity:.4}, {transform:'scale(1)', opacity:1}], {duration:1050})
  ]);
  activate();
}

async function joinStories(oldSlide, incoming, activate) {
  await Promise.all([
    animate(oldSlide, [{transform:'scale(1)', opacity:1}, {transform:'scale(.91)', opacity:0}], {duration:700}),
    animate(incoming, [{opacity:0}, {opacity:1}], {duration:500}),
    animate(incoming.querySelector('.ending-home'), [{transform:'translateX(-100%) scale(1.08)'}, {transform:'translateX(0) scale(1)'}], {duration:1100}),
    animate(incoming.querySelector('.ending-workshop'), [{transform:'translateX(100%) scale(1.08)'}, {transform:'translateX(0) scale(1)'}], {duration:1100})
  ]);
  activate();
}

async function cinematicCut(oldSlide, incoming, direction, activate) {
  await Promise.all([
    animate(oldSlide, [{transform:'translateY(0) scale(1)', opacity:1}, {transform:`translateY(${-direction * 6}%) scale(.95)`, opacity:0}], {duration:680}),
    animate(incoming, [{transform:`translateY(${direction * 8}%) scale(1.04)`, opacity:0}, {transform:'translateY(0) scale(1)', opacity:1}], {duration:780})
  ]);
  activate();
}

async function navigate(target, source = null, focus = true) {
  target = DeckState.normalize(target.scene, target.beat);
  if (moving || dialogs.some(dialog => dialog.open)) return;
  menu.open = false;
  if (target.scene === state.scene) {
    if (target.beat !== state.beat) await reveal(target);
    return;
  }
  if (reduceMotion.matches || typeof surface.animate !== 'function') { commit(target, focus); return; }
  moving = true;
  document.body.classList.add('is-moving');
  const from = state.scene;
  const oldSlide = slides[from];
  const incoming = slides[target.scene];
  let activated = false;
  const activate = () => { if (!activated) { commit(target, focus); activated = true; } };
  incoming.hidden = false;
  incoming.inert = true;
  incoming.classList.remove('is-active');
  incoming.classList.add('is-staged');
  incoming.style.zIndex = '3';
  incoming.scrollTop = 0;
  applyReveal(incoming, target.beat);
  const direction = target.scene > from ? 1 : -1;
  try {
    if ((target.scene === 1 || target.scene === 3) && direction > 0) await travelThroughDoor(oldSlide, incoming, target, source, activate);
    else if ((from === 1 && target.scene === 2) || (from === 2 && target.scene === 1)) await moveCamera(oldSlide, incoming, direction, activate);
    else if ((from === 3 && target.scene === 4) || (from === 4 && target.scene === 3)) await turnPage(oldSlide, incoming, direction, activate);
    else if (target.scene === 5) await joinStories(oldSlide, incoming, activate);
    else await cinematicCut(oldSlide, incoming, direction, activate);
  } catch (_) {
    // A browser that cannot complete an effect still reaches the requested scene.
  } finally {
    activate();
    clearAnimations();
    portalLayer.hidden = true;
    oldSlide.style.transformOrigin = '';
    document.body.classList.remove('is-moving');
    moving = false;
  }
}

const advance = () => navigate(DeckState.forward(state));
const retreat = () => navigate(DeckState.backward(state));
document.querySelectorAll('[data-goto]').forEach(button => button.addEventListener('click', () => navigate(DeckState.normalize(Number(button.dataset.goto)), button)));
document.querySelectorAll('[data-advance]').forEach(button => button.addEventListener('click', advance));
nextButton.addEventListener('click', advance);
previousButton.addEventListener('click', retreat);
document.getElementById('restart-button').addEventListener('click', () => navigate(DeckState.normalize(0)));

function showNotice(message) {
  const notice = document.getElementById('notice');
  notice.textContent = message;
  notice.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = window.setTimeout(() => { notice.hidden = true; }, 5000);
}

async function toggleFullscreen() {
  menu.open = false;
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
    else showNotice('Neste navegador, use a opção de tela cheia do dispositivo.');
  } catch (_) { showNotice('Use a opção de tela cheia do navegador. No computador, tente F11.'); }
}
document.getElementById('fullscreen-button').addEventListener('click', toggleFullscreen);
document.addEventListener('fullscreenchange', () => {
  const full = Boolean(document.fullscreenElement);
  const button = document.getElementById('fullscreen-button');
  button.setAttribute('aria-label', full ? 'Sair da tela cheia' : 'Entrar em tela cheia');
  button.querySelector('span').textContent = full ? 'Sair da tela cheia' : 'Tela cheia';
  if (!dialogs.some(dialog => dialog.open)) slides[state.scene].querySelector('h1,h2').focus({preventScroll:true});
});

const notesContainer = document.getElementById('speaker-notes');
(window.PRESENTATION_NOTES || []).forEach((note, index) => {
  const article = document.createElement('article');
  article.className = 'speaker-note';
  const label = document.createElement('p');
  label.className = 'note-label';
  label.textContent = `PESSOA ${index + 1} · CENA ${String(index + 1).padStart(2, '0')}`;
  const title = document.createElement('h3');
  title.textContent = note.title;
  const paragraph = document.createElement('p');
  paragraph.textContent = note.text;
  article.append(label, title, paragraph);
  notesContainer.append(article);
});

const overviewGrid = document.getElementById('overview-grid');
sceneTitles.forEach((title, index) => {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'overview-item';
  button.setAttribute('aria-label', `Cena ${index + 1}: ${title}`);
  const thumb = document.createElement('span');
  thumb.className = 'overview-thumb';
  thumb.style.backgroundImage = `url('assets/${sceneImages[index]}.png')`;
  thumb.setAttribute('aria-hidden', 'true');
  const number = document.createElement('span');
  number.textContent = String(index + 1).padStart(2, '0');
  thumb.append(number);
  const label = document.createElement('span');
  label.textContent = title;
  button.append(thumb, label);
  button.addEventListener('click', () => { overviewDialog.close(); navigate(DeckState.normalize(index)); });
  overviewGrid.append(button);
});

function openDialog(dialog) {
  if (moving) return;
  menu.open = false;
  if (dialog === notesDialog) Array.from(notesContainer.children).forEach((article, index) => article.classList.toggle('is-current', index === state.scene));
  if (dialog === overviewDialog) Array.from(overviewGrid.children).forEach((button, index) => {
    if (index === state.scene) button.setAttribute('aria-current', 'step');
    else button.removeAttribute('aria-current');
  });
  dialog.showModal();
  dialog.scrollTop = 0;
}
document.getElementById('notes-button').addEventListener('click', () => openDialog(notesDialog));
document.getElementById('sources-button').addEventListener('click', () => openDialog(sourcesDialog));
document.getElementById('overview-button').addEventListener('click', () => openDialog(overviewDialog));
document.querySelectorAll('.close-dialog').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
dialogs.forEach(dialog => dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const rect = dialog.getBoundingClientRect();
  if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
}));
dialogs.forEach(dialog => dialog.addEventListener('close', () => {
  if (!moving && !dialogs.some(item => item.open)) slides[state.scene].querySelector('h1,h2').focus({preventScroll:true});
}));
document.addEventListener('click', event => { if (!menu.contains(event.target)) menu.open = false; });

document.addEventListener('keydown', event => {
  if (event.ctrlKey || event.metaKey || event.altKey || dialogs.some(dialog => dialog.open)) return;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName) || event.target.isContentEditable) return;
  const control = event.target.closest('button,a,summary');
  if (event.key === 'ArrowRight' || event.key === 'PageDown' || (event.code === 'Space' && !control)) { event.preventDefault(); advance(); }
  else if (event.key === 'ArrowLeft' || event.key === 'PageUp') { event.preventDefault(); retreat(); }
  else if (event.key === 'Home') { event.preventDefault(); navigate(DeckState.normalize(0)); }
  else if (event.key === 'End') { event.preventDefault(); navigate(DeckState.normalize(5)); }
  else if (event.key.toLowerCase() === 'f') { event.preventDefault(); toggleFullscreen(); }
  else if (event.key.toLowerCase() === 'r') { event.preventDefault(); openDialog(notesDialog); }
  else if (event.key.toLowerCase() === 'g') { event.preventDefault(); openDialog(overviewDialog); }
  else if (event.key === 'Escape') menu.open = false;
});

let touchStart;
surface.addEventListener('touchstart', event => {
  if (moving || event.touches.length !== 1 || event.target.closest('button,a')) { touchStart = null; return; }
  touchStart = {x:event.touches[0].clientX,y:event.touches[0].clientY};
}, {passive:true});
surface.addEventListener('touchend', event => {
  if (!touchStart) return;
  const point = event.changedTouches[0];
  const dx = point.clientX - touchStart.x;
  const dy = point.clientY - touchStart.y;
  if (Math.abs(dx) > 75 && Math.abs(dx) > Math.abs(dy) * 1.8) { if (dx < 0) advance(); else retreat(); }
  touchStart = null;
}, {passive:true});
surface.addEventListener('touchcancel', () => { touchStart = null; }, {passive:true});

const pointerIsFine = window.matchMedia('(hover: hover) and (pointer: fine)');
document.querySelectorAll('.portal-card').forEach(card => {
  const visual = card.querySelector('.portal-visual');
  card.addEventListener('pointermove', event => {
    if (reduceMotion.matches || !pointerIsFine.matches || moving) return;
    const rect = visual.getBoundingClientRect();
    const x = Math.max(-.5, Math.min(.5, (event.clientX - rect.left) / rect.width - .5));
    const y = Math.max(-.5, Math.min(.5, (event.clientY - rect.top) / rect.height - .5));
    visual.style.setProperty('--tilt-x', `${x * 6}deg`);
    visual.style.setProperty('--tilt-y', `${-y * 5}deg`);
  });
  card.addEventListener('pointerleave', () => { visual.style.setProperty('--tilt-x','0deg'); visual.style.setProperty('--tilt-y','0deg'); });
});

window.addEventListener('hashchange', () => { if (!moving) navigate(DeckState.parse(location.hash), null, false); });
reduceMotion.addEventListener('change', () => { if (reduceMotion.matches) clearAnimations(); });
commit(DeckState.parse(location.hash), false, false);
['doors','home','workshop'].forEach(name => { const image = new Image(); image.src = `assets/${name}.png`; });
